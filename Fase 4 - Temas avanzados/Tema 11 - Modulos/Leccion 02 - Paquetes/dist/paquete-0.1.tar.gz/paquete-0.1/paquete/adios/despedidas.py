# Este es un módulo con funciones que despiden

def despedirse():
	print('Adios, me estoy despidiendo desde la función despedirse del módulo despedidas')

class Despedida():

	def __init__(self):
		print('Adios, me estoy despidiendo desde la clase Despedida del módulo despedidas')