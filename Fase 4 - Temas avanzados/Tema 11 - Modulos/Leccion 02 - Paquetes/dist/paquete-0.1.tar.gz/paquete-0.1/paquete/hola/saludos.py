# Este es un módulo con funciones que saludan

def saludar():
	print('Hola, te estoy saludando desde la función saludar del módulo saludos')

class Saludo():

	def __init__(self):
		print('Hola, te estoy saludando desde la clase Saludo del módulo saludos')