from setuptools import setup

setup(
	name='paquete',
	version='0.1',
	description='Este es un paquete de ejemplo',
	author='Emanuel Flores',
	author_email='yo@muf.com',
	scripts=[],
	packages=['paquete', 'paquete.adios', 'paquete.hola']
)